export energy

"""
    energy(w::WaveOrthotope, component=:total)

Return the specified component of the energy contained in `w`.

`component` can be `:total`, `:dynamic`, or `:potential`.
"""
function energy(w::WaveOrthotope{<:Real, 2}, component=:total)
    component in (:total, :dynamic, :potential) ||
        throw(ArgumentError("Energy component must be :total, :dynamic, or :potential"))

    m, n = size(w)
    u, v = w.u, w.v

    # Use a floating-point accumulator
    E = zero(eltype(u))

    # Decide once
    want_dynamic   = component != :potential
    want_potential = component != :dynamic

    # Dynamic energy
    if want_dynamic
        @inbounds @simd for j in 2:n-1
            for i in 2:m-1
                E += (v[i, j]^2) * 0.5
            end
        end
    end

    # Potential energy (x-direction)
    if want_potential
        @inbounds @simd for j in 2:n-1
            for i in 1:m-1
                d = u[i, j] - u[i+1, j]
                E += (d * d) * 0.25
            end
        end

        # Potential energy (y-direction)
        @inbounds @simd for j in 1:n-1
            for i in 2:m-1
                d = u[i, j] - u[i, j+1]
                E += (d * d) * 0.25
            end
        end
    end

    return E
end
