export step!

"""
    step!(w::WaveOrthotope, dt=$defaultdt)

ND leapfrog integrator.
"""
function step!(w::WaveOrthotope{<:Real, N}, dt=defaultdt) where N
    c = w.c
    u = interior(w.u)
    v = interior(w.v)
    a = adjacents(u)

    if dt < 0
        @. u += dt*v
        L = @. +(a...)/2 - N*u
        @. v = (v+dt*L) / (1+dt*c)
    else
        L = @. +(a...)/2 - N*u
        @. v = (1-dt*c)*v + dt*L
        @. u += dt*v
    end

    w.t[] += dt
    return w
end
