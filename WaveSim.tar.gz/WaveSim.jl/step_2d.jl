export step!

"""
    step!(w::WaveOrthotope, dt=defaultdt)

Optimized 2D leapfrog step with no allocations.

Most users will need to squeeze performance out of Julia. Use `@profview` liberally to see
where time is being taken; if you're spending most of your runtime somewhere other than
`step!` or `energy`, that's a sign you still have unnecessary work, allocations, or type
instabilities elsewhere.
"""
function step!(w::WaveOrthotope{<:Real,2}, dt=defaultdt) 
    dt < 0 && throw(ArgumentError("Stepping back is not supported."))

    m, n = size(w)
    u = w.u
    v = w.v
    c = w.c
    half = 0.5
    dt_c = dt * c

    @inbounds for j in 2:n-1
        @simd for i in 2:m-1
            uij = u[i,j]
            vij = v[i,j]
            L = (u[i-1,j] + u[i+1,j] + u[i,j-1] + u[i,j+1] - 4*uij) * half
            vij += dt*L - dt_c*vij      # dt*(L - c*vij)
            v[i,j] = vij
        end
    end

    @inbounds for j in 2:n-1
        @simd for i in 2:m-1
            u[i,j] += dt * v[i,j]
        end
    end

    w.t[] += dt
    return w
end

